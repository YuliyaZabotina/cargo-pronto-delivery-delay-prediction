# Функции для подготовки данных и построения признаков
# Проект: Модель прогнозирования задержек доставки для CargaPronto

import pandas as pd
import numpy as np

def clean_orders_data(df_orders):
    df_orders = df_orders.copy()

    # Удаляем лишние пробелы в category_name
    df_orders["category_name"] = df_orders["category_name"].str.strip()

    # Создаем временные признаки
    df_orders["order_month"] = df_orders["order_date"].dt.month
    df_orders["order_weekday"] = df_orders["order_date"].dt.isocalendar().day.astype(int)
    df_orders["order_hour"] = df_orders["order_date"].dt.hour

    return df_orders


def remove_geo_anomalies(df_customers, df_orders):
    df_customers = df_customers.copy()
    df_orders = df_orders.copy()

    # Ищем клиентов с аномальной долготой
    geo_anomalies = df_customers[
        (df_customers["customer_lon"] < -125) | (df_customers["customer_lon"] > -20)
    ]

    anomalous_customer_ids = geo_anomalies["customer_id"].unique()

    # Удаляем аномальных клиентов
    df_customers = df_customers[
        ~df_customers["customer_id"].isin(anomalous_customer_ids)
    ].copy()

    # Удаляем связанные заказы
    df_orders = df_orders[
        ~df_orders["customer_id"].isin(anomalous_customer_ids)
    ].copy()

    df_customers = df_customers.reset_index(drop=True)
    df_orders = df_orders.reset_index(drop=True)

    return df_customers, df_orders


def build_cluster_features(df_customers, geo_pipe, beh_pipe, geo_features, beh_features):
    df_customers = df_customers.copy()

    X_geo_all = df_customers[geo_features].copy()
    X_beh_all = df_customers[beh_features].copy()

    df_customers["geo_cluster"] = geo_pipe.predict(X_geo_all)
    df_customers["beh_cluster"] = beh_pipe.predict(X_beh_all)

    return df_customers


def add_cluster_features_to_orders(df_orders, df_customers):
    df_orders = df_orders.copy()

    df_orders = df_orders.merge(
        df_customers[["customer_id", "geo_cluster", "beh_cluster"]],
        on="customer_id",
        how="left"
    )

    return df_orders


def prepare_model_data(df_orders, feature_list):
    df_orders = df_orders.copy()
    X = df_orders[feature_list].copy()
    return X


